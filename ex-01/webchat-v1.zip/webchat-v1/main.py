from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from openai import OpenAI
import os
import uuid
from collections import defaultdict
from typing import Optional

app = FastAPI(title="AI Agent Chat API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory conversation history (mimics n8n memoryBufferWindow)
conversation_history = defaultdict(list)

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "your-openrouter-api-key-here")
MODEL = os.getenv("MODEL", "z-ai/glm-4.5v")
SYSTEM_PROMPT = os.getenv("SYSTEM_PROMPT", "You are a helpful AI assistant.")
MEMORY_WINDOW = int(os.getenv("MEMORY_WINDOW", "10"))  # last N messages to keep

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    session_id: str

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())
    
    # Build messages with history (memory window)
    history = conversation_history[session_id][-MEMORY_WINDOW * 2:]  # *2 for user+assistant pairs
    
    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [
        {"role": "user", "content": req.message}
    ]
    
    try:
        completion = client.chat.completions.create(
            model=MODEL,
            messages=messages,
        )
        reply = completion.choices[0].message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI Agent error: {str(e)}")
    
    # Save to memory
    conversation_history[session_id].append({"role": "user", "content": req.message})
    conversation_history[session_id].append({"role": "assistant", "content": reply})
    
    return ChatResponse(response=reply, session_id=session_id)

@app.delete("/api/chat/{session_id}")
async def clear_history(session_id: str):
    conversation_history.pop(session_id, None)
    return {"message": "Conversation cleared"}

@app.get("/api/health")
async def health():
    return {"status": "ok", "model": MODEL}

# Serve frontend
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")
