# AI Agent Chat — Python + Docker

Converted from your n8n workflow:
- **Chat Trigger** → FastAPI HTTP endpoint `/api/chat`
- **OpenRouter GLM-4.5v** → `openai` SDK via OpenRouter API  
- **Memory Buffer Window** → In-memory session history (last 10 turns)
- **Web Frontend** → LINE-style chat UI served at `/`

---

## Quick Start

### 1. Configure environment
```bash
cp .env.example .env
# Edit .env and set your OPENROUTER_API_KEY
```

### 2a. Run with Docker (recommended)
```bash
docker compose up --build
```
Open → http://localhost:8000

### 2b. Run locally (Python)
```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Open → http://localhost:8000

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/chat` | Send a message to AI Agent |
| `DELETE` | `/api/chat/{session_id}` | Clear conversation history |
| `GET` | `/api/health` | Health check |

### POST /api/chat
```json
// Request
{ "message": "Hello!", "session_id": "optional-uuid" }

// Response
{ "response": "Hi! How can I help?", "session_id": "uuid-..." }
```

---

## Configuration (.env)

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENROUTER_API_KEY` | *(required)* | Your OpenRouter API key |
| `MODEL` | `z-ai/glm-4.5v` | OpenRouter model ID |
| `SYSTEM_PROMPT` | `You are a helpful AI assistant.` | Agent system prompt |
| `MEMORY_WINDOW` | `10` | Number of past messages to remember |

---

## Project Structure
```
.
├── main.py              # FastAPI backend
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── static/
    └── index.html       # Web chat UI
```
